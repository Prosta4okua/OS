gcc 2.c -o 2 -lm -pthread
./2
