gcc 3.c -o 3 -lm -pthread
./3
